/*
Faculty records contain an integer Faculty ID, a string name, a string level (lecturer, assistant prof, associate prof, etc.), a string department, 
and a list of integers corresponding to all of the faculty member’s advisees’ ids. These are the only fields the class contains.
*/

#ifndef FACULTY_H
#define FACULTY_H

#include <string>
#include "DblList.h"
#include <fstream>

using namespace std;

class Faculty {
public:
    Faculty(int id, string name, string level, string dept);
    ~Faculty();
    int getid();
    void addStudent(int id);
    void removeStudent(int id);
    bool hasStudent(int id);
    void printInfo();
    void printToFile(ofstream &writer);
    bool operator == (Faculty &rhs);
    bool operator > (Faculty &rhs);
    bool operator < (Faculty &rhs);
    DblList<int>* getAdvisees();
    // need to implement changing the advisors for this faculty's students if this is deleted
private:
    int id;
    string name;
    string level;
    string dept;
    DblList<int> *students;
};

#endif 
